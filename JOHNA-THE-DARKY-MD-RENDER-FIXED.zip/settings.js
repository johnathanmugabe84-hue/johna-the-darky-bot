const settings = {
  packname: '𝐉ᴜɴᴇ 𝐌ᴅ',
  author: 'supreme',
  botName: "𝕵𝖔𝖍𝖓𝖆 𝖙𝖍𝖊 𝕯𝖆𝖗𝖐𝖞",
  botOwner: 'Supreme', // Your name
  ownerNumber: ["256763566813"],
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.2.0",
};

module.exports = settings;

const fs = require('fs')

//~~~~~~~~~~~ Settings Owner ~~~~~~~~~~~//
global.owner = "𝕵𝖔𝖍𝖆𝖓𝖝𝖆 𝕷𝕬 𝖁𝖊𝖓𝖊𝖓𝖚"
global.developer = "256763566813"
global.bot = "𝕵𝖔𝖍𝖓𝖆 𝖙𝖍𝖊 𝕯𝖆𝖗𝖐𝖞"
global.devname = "Supreme"
global.ownername = "Supreme"
global.botname = "June Md"
global.versisc = "2"
global.packname = "⎋June Md"
//~~~~~~~~~~~ Settings Sosmed ~~~~~~~~~~~//
global.linkwa = "https://wa.me/256763566813"
global.linkyt = "https://www.youtube.com/supreme"
global.linktt = "https://tiktok.com"
global.linktele = "https://t.me"

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.prefix = ["","!",".",",","#","/","🎭","〽️"]
global.autoRecording = false
global.autoTyping = true
global.autorecordtype = false
global.autoread = true
global.autobio = false
global.anti92 = false
global.owneroff = false
global.autoswview = true

//~~~~~~~~~~~ Settings Thumbnail ~~~~~~~~~~~//
global.thumbbot = "𝕵𝖔𝖍𝖓𝖆 𝖙𝖍𝖊 𝕯𝖆𝖗𝖐𝖞"
global.thumbown = "https://url.bwmxmd.online/Adams.poh4tuhs.jpg"

//~~~~~~~~~~~ Settings Channel ~~~~~~~~~~~//
global.idchannel = "120363402785346228@newsletter*"
global.channelname = "ー𝕵𝖔𝖍𝖓𝖆 𝖙𝖍𝖊 𝕯𝖆𝖗𝖐𝖞 MD UPDATES"
global.channel = "hatsapp.com/channel/0029Vb2W2vAADTOKmdoDxB0m"

//~~~~~~~~~~~ Settings Message ~~~~~~~~~~~//
global.mess = {
  developer: " `[ Developer Only!! ]` \n This feature is for developers only!!",
  owner: " `[ Owner Only!! ]` \n This feature is for owners only!!"= "𝕵𝖔𝖍𝖆𝖓𝖝𝖆 𝕷𝕬 𝖁𝖊𝖓𝖊𝖓𝖚",
  group: " `[ Group Only!! ]` \n This feature is for group chats only!!",
  private: " `[ Private Only!! ]` \n This feature is for private chats only!!",
  admin: " `[ Admin Only!! ]` \n This feature is for admins only!!",
  botadmin: " `[ Bot Admin Only!! ]` \n This feature is for bot admins only!!",
  wait: " `[ Wait!! ]` \n Please wait, loading...",
  error: " `[ Error!! ]` \n An error occurred!!",
  done: " `[ Done!! ]` \n Process completed!!"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
